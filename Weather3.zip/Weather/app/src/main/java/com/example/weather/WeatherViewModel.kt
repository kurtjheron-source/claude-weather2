package com.example.weather

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val snapshot: WeatherSnapshot? = null,
    val loading: Boolean = false,
    val error: String? = null,
    val hasLocation: Boolean = false,
    val hasBackground: Boolean = false,
)

class WeatherViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(
        UiState(
            snapshot = WeatherStore.load(app),
            hasLocation = LocationProvider.hasForeground(app),
            hasBackground = LocationProvider.hasBackground(app),
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    fun refresh() {
        val app = getApplication<Application>()
        viewModelScope.launch {
            _state.update {
                it.copy(
                    loading = true, error = null,
                    hasLocation = LocationProvider.hasForeground(app),
                    hasBackground = LocationProvider.hasBackground(app),
                )
            }
            val snap = WeatherRefresher.refresh(app)
            _state.update {
                it.copy(
                    snapshot = snap ?: it.snapshot,
                    loading = false,
                    error = when {
                        snap != null -> null
                        !LocationProvider.hasForeground(app) -> "Location is off. Allow it to see the weather where you are."
                        else -> "Couldn't update. Check your connection and that location is turned on."
                    },
                )
            }
        }
    }
}
