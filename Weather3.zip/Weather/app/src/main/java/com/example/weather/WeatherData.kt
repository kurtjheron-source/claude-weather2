package com.example.weather

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.TextStyle
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** The visual "mood" of the app and widget, chosen from the real conditions at your location. */
enum class Sky(val bgRes: Int, val top: Long, val bottom: Long) {
    CLEAR_DAY(R.drawable.bg_clear_day, 0xFF4FA3F7, 0xFF1E6FD9),
    CLEAR_NIGHT(R.drawable.bg_clear_night, 0xFF0F1B3D, 0xFF2B3A67),
    HOT(R.drawable.bg_hot, 0xFFF59E42, 0xFFE0562B),
    CLOUDY(R.drawable.bg_cloudy, 0xFF7C8A9A, 0xFF4F5B69),
    RAIN(R.drawable.bg_rain, 0xFF4A5F78, 0xFF26374D),
    STORM(R.drawable.bg_storm, 0xFF3A3350, 0xFF1A1626),
    SNOW(R.drawable.bg_snow, 0xFF7C9AB8, 0xFF4E6D8C),
    FOG(R.drawable.bg_fog, 0xFF8E9A9D, 0xFF5F6B6E),
}

fun skyFor(code: Int, isDay: Boolean, heatIndexC: Double): Sky = when (code) {
    0, 1 -> when {
        !isDay -> Sky.CLEAR_NIGHT
        heatIndexC >= 32.0 -> Sky.HOT
        else -> Sky.CLEAR_DAY
    }
    2 -> if (isDay) Sky.CLOUDY else Sky.CLEAR_NIGHT
    3 -> Sky.CLOUDY
    45, 48 -> Sky.FOG
    in 51..67, in 80..82 -> Sky.RAIN
    in 71..77, 85, 86 -> Sky.SNOW
    in 95..99 -> Sky.STORM
    else -> Sky.CLOUDY
}

fun conditionLabel(code: Int): String = when (code) {
    0 -> "Clear"
    1 -> "Mostly clear"
    2 -> "Partly cloudy"
    3 -> "Overcast"
    45, 48 -> "Fog"
    51, 53, 55 -> "Drizzle"
    56, 57 -> "Freezing drizzle"
    61 -> "Light rain"
    63 -> "Rain"
    65 -> "Heavy rain"
    66, 67 -> "Freezing rain"
    71 -> "Light snow"
    73 -> "Snow"
    75 -> "Heavy snow"
    77 -> "Snow grains"
    80 -> "Light showers"
    81 -> "Showers"
    82 -> "Violent showers"
    85, 86 -> "Snow showers"
    95 -> "Thunderstorm"
    96, 99 -> "Thunderstorm with hail"
    else -> "Unsettled"
}

fun conditionEmoji(code: Int, isDay: Boolean): String = when (code) {
    0 -> if (isDay) "☀️" else "🌙"
    1 -> if (isDay) "🌤️" else "🌙"
    2 -> if (isDay) "⛅" else "☁️"
    3 -> "☁️"
    45, 48 -> "🌫️"
    in 51..57 -> "🌦️"
    in 61..67, in 80..82 -> "🌧️"
    in 71..77, 85, 86 -> "❄️"
    in 95..99 -> "⛈️"
    else -> "🌡️"
}

/** NWS heat index (Rothfusz regression with the standard adjustments). Works in °C. */
fun heatIndexC(tempC: Double, humidity: Int): Double {
    val t = tempC * 9 / 5 + 32
    val rh = humidity.toDouble()
    val simple = 0.5 * (t + 61.0 + (t - 68.0) * 1.2 + rh * 0.094)
    val hiF = if ((simple + t) / 2 >= 80.0) {
        var hi = -42.379 + 2.04901523 * t + 10.14333127 * rh - 0.22475541 * t * rh -
            0.00683783 * t * t - 0.05481717 * rh * rh + 0.00122874 * t * t * rh +
            0.00085282 * t * rh * rh - 0.00000199 * t * t * rh * rh
        if (rh < 13 && t in 80.0..112.0) hi -= ((13 - rh) / 4) * sqrt((17 - abs(t - 95)) / 17)
        if (rh > 85 && t in 80.0..87.0) hi += ((rh - 85) / 10) * ((87 - t) / 5)
        hi
    } else simple
    return (hiF - 32) * 5 / 9
}

fun heatLabel(hiC: Double, tempC: Double): String = when {
    hiC >= 51.7 -> "Extreme danger"
    hiC >= 39.4 -> "Danger"
    hiC >= 32.2 -> "Extreme caution"
    hiC >= 26.7 -> "Caution"
    tempC < 10 -> "Cool"
    else -> "No heat stress"
}

fun rainLabel(p: Int) = when {
    p >= 70 -> "Likely"
    p >= 40 -> "Possible"
    else -> "Unlikely"
}

fun humidityLabel(h: Int) = when {
    h < 30 -> "Dry"
    h <= 60 -> "Comfortable"
    h <= 75 -> "Humid"
    else -> "Very humid"
}

object Units {
    private val imperialCountries = setOf("US", "LR", "MM", "BS", "BZ", "KY", "PW")
    private val imperial get() = Locale.getDefault().country in imperialCountries
    fun temp(c: Double): String = "${(if (imperial) c * 9 / 5 + 32 else c).roundToInt()}°"
    fun wind(kmh: Double): String =
        if (imperial) "${(kmh * 0.621371).roundToInt()} mph" else "${kmh.roundToInt()} km/h"
}

data class HourPoint(val label: String, val tempC: Double, val code: Int, val isDay: Boolean, val rain: Int)
data class DayPoint(val label: String, val code: Int, val maxC: Double, val minC: Double, val rain: Int)

data class WeatherSnapshot(
    val tempC: Double,
    val feelsC: Double,
    val humidity: Int,
    val heatIndexC: Double,
    val rainChance: Int,
    val windKmh: Double,
    val code: Int,
    val isDay: Boolean,
    val place: String,
    val lat: Double,
    val lon: Double,
    val updatedMs: Long,
    val hours: List<HourPoint> = emptyList(),
    val days: List<DayPoint> = emptyList(),
) {
    val sky get() = skyFor(code, isDay, heatIndexC)
    val label get() = conditionLabel(code)
    val emoji get() = conditionEmoji(code, isDay)

    fun toJson(): String {
        val hs = JSONArray()
        hours.forEach {
            hs.put(JSONObject().put("l", it.label).put("t", it.tempC).put("c", it.code).put("d", it.isDay).put("r", it.rain))
        }
        val ds = JSONArray()
        days.forEach {
            ds.put(JSONObject().put("l", it.label).put("c", it.code).put("x", it.maxC).put("n", it.minC).put("r", it.rain))
        }
        return JSONObject()
            .put("t", tempC).put("f", feelsC).put("h", humidity).put("hi", heatIndexC)
            .put("r", rainChance).put("w", windKmh).put("c", code).put("d", isDay)
            .put("p", place).put("lat", lat).put("lon", lon).put("u", updatedMs)
            .put("hrs", hs).put("days", ds).toString()
    }

    companion object {
        fun fromJson(s: String): WeatherSnapshot? = try {
            val o = JSONObject(s)
            val hs = o.optJSONArray("hrs")
            val ds = o.optJSONArray("days")
            WeatherSnapshot(
                o.getDouble("t"), o.getDouble("f"), o.getInt("h"), o.getDouble("hi"),
                o.getInt("r"), o.getDouble("w"), o.getInt("c"), o.getBoolean("d"),
                o.getString("p"), o.getDouble("lat"), o.getDouble("lon"), o.getLong("u"),
                hours = (0 until (hs?.length() ?: 0)).map {
                    val x = hs!!.getJSONObject(it)
                    HourPoint(x.getString("l"), x.getDouble("t"), x.getInt("c"), x.getBoolean("d"), x.getInt("r"))
                },
                days = (0 until (ds?.length() ?: 0)).map {
                    val x = ds!!.getJSONObject(it)
                    DayPoint(x.getString("l"), x.getInt("c"), x.getDouble("x"), x.getDouble("n"), x.getInt("r"))
                },
            )
        } catch (e: Exception) {
            null
        }
    }
}

object WeatherStore {
    private fun prefs(c: Context) = c.getSharedPreferences("weather", Context.MODE_PRIVATE)
    fun save(c: Context, s: WeatherSnapshot) = prefs(c).edit().putString("snap", s.toJson()).apply()
    fun load(c: Context): WeatherSnapshot? =
        prefs(c).getString("snap", null)?.let { WeatherSnapshot.fromJson(it) }
}

private fun hourLabel(iso: String): String {
    val h = iso.substring(11, 13).toInt()
    val h12 = (h % 12).let { if (it == 0) 12 else it }
    return "$h12 ${if (h < 12) "AM" else "PM"}"
}

/** Live data from Open-Meteo (free, no API key). */
object WeatherApi {
    suspend fun fetch(lat: Double, lon: Double, place: String): WeatherSnapshot =
        withContext(Dispatchers.IO) {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m" +
                    "&hourly=temperature_2m,precipitation_probability,weather_code,is_day" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                    "&forecast_days=7&timezone=auto"
            )
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 15_000
            }
            try {
                val root = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val cur = root.getJSONObject("current")
                val hourly = root.getJSONObject("hourly")
                val times = hourly.getJSONArray("time")
                val hT = hourly.getJSONArray("temperature_2m")
                val hR = hourly.getJSONArray("precipitation_probability")
                val hC = hourly.getJSONArray("weather_code")
                val hD = hourly.getJSONArray("is_day")
                val hourKey = cur.getString("time").take(13)
                var idx = 0
                for (i in 0 until times.length()) {
                    if (times.getString(i).startsWith(hourKey)) { idx = i; break }
                }
                val hours = (idx until minOf(idx + 24, times.length())).map { i ->
                    HourPoint(
                        if (i == idx) "Now" else hourLabel(times.getString(i)),
                        hT.optDouble(i, 0.0), hC.optInt(i, 0), hD.optInt(i, 1) == 1, hR.optInt(i, 0),
                    )
                }
                val daily = root.getJSONObject("daily")
                val dT = daily.getJSONArray("time")
                val dC = daily.getJSONArray("weather_code")
                val dX = daily.getJSONArray("temperature_2m_max")
                val dN = daily.getJSONArray("temperature_2m_min")
                val dR = daily.getJSONArray("precipitation_probability_max")
                val days = (0 until dT.length()).map { i ->
                    DayPoint(
                        if (i == 0) "Today" else LocalDate.parse(dT.getString(i)).dayOfWeek
                            .getDisplayName(TextStyle.SHORT, Locale.getDefault()),
                        dC.optInt(i, 0), dX.optDouble(i, 0.0), dN.optDouble(i, 0.0), dR.optInt(i, 0),
                    )
                }
                val temp = cur.getDouble("temperature_2m")
                val hum = cur.getInt("relative_humidity_2m")
                WeatherSnapshot(
                    tempC = temp,
                    feelsC = cur.getDouble("apparent_temperature"),
                    humidity = hum,
                    heatIndexC = heatIndexC(temp, hum),
                    rainChance = hR.optInt(idx, 0),
                    windKmh = cur.getDouble("wind_speed_10m"),
                    code = cur.getInt("weather_code"),
                    isDay = cur.getInt("is_day") == 1,
                    place = place,
                    lat = lat,
                    lon = lon,
                    updatedMs = System.currentTimeMillis(),
                    hours = hours,
                    days = days,
                )
            } finally {
                conn.disconnect()
            }
        }
}
