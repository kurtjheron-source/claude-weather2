package com.example.weather

import android.Manifest
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.runtime.State
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.DateFormat
import java.util.Date
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private val vm: WeatherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
        )
        WeatherUpdateWorker.schedulePeriodic(this)
        setContent { MaterialTheme { WeatherScreen(vm) } }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh()
    }
}

private val Ink = Color.White
private val Dim = Color.White.copy(alpha = 0.74f)
private val RainBlue = Color(0xFF9BE3FF)

/** Frosted-glass panel: translucent white fill plus a light-catching edge. */
private fun Modifier.glass(radius: Dp = 26.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.24f), Color.White.copy(alpha = 0.10f))))
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.60f), Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.28f))),
            shape,
        )
}

@Composable
fun WeatherScreen(vm: WeatherViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val s = state.snapshot
    val sky = s?.sky ?: Sky.CLEAR_DAY

    val fgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.refresh() }
    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refresh() }
    val askLocation = {
        fgLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
    }

    LaunchedEffect(Unit) { if (!LocationProvider.hasForeground(ctx)) askLocation() }

    Box(Modifier.fillMaxSize()) {
        Crossfade(targetState = sky, animationSpec = tween(900), label = "sky") { SkyBackdrop(it) }

        Column(
            Modifier.fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 16.dp)
        ) {
            if (state.loading) {
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = Ink, trackColor = Ink.copy(alpha = 0.2f))
            } else {
                Spacer(Modifier.height(4.dp))
            }

            Row(Modifier.fillMaxWidth().padding(start = 6.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s?.place ?: "Weather", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Normal)
                    if (s != null) {
                        Text(
                            "📍 Updated " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(s.updatedMs)),
                            color = Dim, fontSize = 13.sp,
                        )
                    }
                }
                TextButton(onClick = { vm.refresh() }) { Text("↻", color = Ink, fontSize = 28.sp) }
            }

            if (s != null) {
                Hero(s)
                GlassCard("Hourly forecast") {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 6.dp)) {
                        s.hours.forEach { HourItem(it) }
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (s.days.isNotEmpty()) {
                    GlassCard("7-day forecast") {
                        val wMin = s.days.minOf { it.minC }
                        val wMax = s.days.maxOf { it.maxC }
                        s.days.forEachIndexed { i, d ->
                            if (i > 0) HorizontalDivider(Modifier.padding(horizontal = 18.dp), color = Ink.copy(alpha = 0.15f))
                            DayRow(d, wMin, wMax, if (i == 0) s.tempC else null)
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Tile("Humidity", "${s.humidity}%", humidityLabel(s.humidity), Modifier.weight(1f))
                    Tile("Heat index", Units.temp(s.heatIndexC), heatLabel(s.heatIndexC, s.tempC), Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Tile("Chance of rain", "${s.rainChance}%", rainLabel(s.rainChance) + " this hour", Modifier.weight(1f))
                    Tile("Wind", Units.wind(s.windKmh), "Feels like ${Units.temp(s.feelsC)}", Modifier.weight(1f))
                }
            } else {
                Column(Modifier.fillMaxWidth().padding(top = 96.dp, bottom = 24.dp)) {
                    Text("Weather where you are", color = Ink, fontSize = 38.sp, fontWeight = FontWeight.Light, lineHeight = 44.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("Allow location and the live conditions, forecast and widget will appear here.", color = Dim, fontSize = 16.sp)
                }
            }

            state.error?.let {
                Spacer(Modifier.height(14.dp))
                Text(it, color = Ink, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 6.dp))
            }

            if (!state.hasLocation) {
                Spacer(Modifier.height(12.dp))
                GlassCard("Location is off") {
                    TextButton(onClick = { askLocation() }, modifier = Modifier.padding(start = 6.dp)) {
                        Text("Allow location", color = Ink, fontSize = 16.sp)
                    }
                }
            } else if (!state.hasBackground && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                Spacer(Modifier.height(12.dp))
                GlassCard("Keep the widget fresh") {
                    Text(
                        "To follow you while the app is closed, set location to “Allow all the time”.",
                        color = Ink, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 18.dp),
                    )
                    TextButton(onClick = { bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION) }, modifier = Modifier.padding(start = 6.dp)) {
                        Text("Allow all the time", color = Ink, fontSize = 16.sp)
                    }
                }
            }

            Text(
                "Add the widget: touch and hold your home screen, tap Widgets, then Weather. Resize it to any size.",
                color = Dim, fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 24.dp),
            )
        }
    }
}

@Composable
private fun Hero(s: WeatherSnapshot) {
    val today = s.days.firstOrNull()
    Column(
        Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(Units.temp(s.tempC), color = Ink, fontSize = 150.sp, lineHeight = 150.sp, fontWeight = FontWeight.ExtraLight)
        Text("${s.emoji}  ${s.label}", color = Ink, fontSize = 24.sp)
        if (today != null) {
            Text("H ${Units.temp(today.maxC)}   L ${Units.temp(today.minC)}", color = Dim, fontSize = 18.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun GlassCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().glass()) {
        Text(title, color = Dim, fontSize = 14.sp, modifier = Modifier.padding(start = 18.dp, top = 14.dp, bottom = 4.dp))
        content()
    }
}

@Composable
private fun HourItem(h: HourPoint) {
    Column(Modifier.width(62.dp).padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(h.label, color = Ink, fontSize = 14.sp, maxLines = 1)
        Text(conditionEmoji(h.code, h.isDay), fontSize = 26.sp, modifier = Modifier.padding(vertical = 6.dp))
        Text(Units.temp(h.tempC), color = Ink, fontSize = 18.sp)
        Text(if (h.rain >= 20) "${h.rain}%" else " ", color = RainBlue, fontSize = 12.sp)
    }
}

@Composable
private fun DayRow(d: DayPoint, weekMin: Double, weekMax: Double, now: Double?) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(d.label, color = Ink, fontSize = 17.sp, modifier = Modifier.width(62.dp))
        Text(conditionEmoji(d.code, true), fontSize = 22.sp, modifier = Modifier.width(34.dp))
        Text(if (d.rain >= 20) "${d.rain}%" else "", color = RainBlue, fontSize = 12.sp, modifier = Modifier.width(36.dp))
        Text(Units.temp(d.minC), color = Dim, fontSize = 17.sp, textAlign = TextAlign.End, modifier = Modifier.width(42.dp))
        Box(
            Modifier.weight(1f).padding(horizontal = 10.dp).height(6.dp).drawBehind {
                val r = CornerRadius(size.height / 2)
                drawRoundRect(Color.White.copy(alpha = 0.22f), cornerRadius = r)
                val span = (weekMax - weekMin).coerceAtLeast(1.0)
                val x0 = ((d.minC - weekMin) / span * size.width).toFloat()
                val x1 = ((d.maxC - weekMin) / span * size.width).toFloat().coerceAtLeast(x0 + size.height)
                drawRoundRect(
                    Brush.horizontalGradient(listOf(Color(0xFF7FD6FF), Color(0xFFFFD166), Color(0xFFFF7A59)), startX = x0, endX = x1),
                    topLeft = Offset(x0, 0f), size = Size(x1 - x0, size.height), cornerRadius = r,
                )
                if (now != null) {
                    val nx = ((now - weekMin) / span * size.width).toFloat().coerceIn(size.height / 2, size.width - size.height / 2)
                    drawCircle(Color.White, radius = size.height * 0.8f, center = Offset(nx, size.height / 2))
                }
            }
        ) {}
        Text(Units.temp(d.maxC), color = Ink, fontSize = 17.sp, modifier = Modifier.width(44.dp))
    }
}

@Composable
private fun Tile(label: String, value: String, note: String, modifier: Modifier = Modifier) {
    Column(modifier.glass().padding(horizontal = 18.dp, vertical = 14.dp).height(112.dp)) {
        Text(label, color = Dim, fontSize = 14.sp)
        Text(value, color = Ink, fontSize = 40.sp, fontWeight = FontWeight.ExtraLight, modifier = Modifier.padding(top = 2.dp))
        Text(note, color = Dim, fontSize = 13.sp, maxLines = 1)
    }
}

// ---------- the sky behind everything (animated) ----------

private fun DrawScope.glow(center: Offset, radius: Float, alpha: Float) {
    drawCircle(
        Brush.radialGradient(listOf(Color.White.copy(alpha = alpha), Color.Transparent), center = center, radius = radius),
        radius = radius, center = center,
    )
}

/** A 0..1 value that loops forever (or ping-pongs when [reverse] is set). */
@Composable
private fun loopT(ms: Int, reverse: Boolean = false): State<Float> {
    val tr = rememberInfiniteTransition(label = "loop")
    return tr.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(ms, easing = LinearEasing), if (reverse) RepeatMode.Reverse else RepeatMode.Restart),
        label = "t",
    )
}

@Composable
private fun SkyBackdrop(sky: Sky) {
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) { drawRect(Brush.verticalGradient(listOf(Color(sky.top), Color(sky.bottom)))) }
        when (sky) {
            Sky.CLEAR_DAY, Sky.HOT -> SunLayer()
            Sky.CLEAR_NIGHT -> NightLayer()
            Sky.CLOUDY -> CloudLayer(1f)
            Sky.FOG -> CloudLayer(1.7f)
            Sky.RAIN -> { CloudLayer(1f); RainLayer(false) }
            Sky.STORM -> { CloudLayer(1.2f); RainLayer(true) }
            Sky.SNOW -> { CloudLayer(1f); SnowLayer() }
        }
    }
}

/** Sunny: the sun breathes and slow light rays sweep around it. */
@Composable
private fun SunLayer() {
    val spin by loopT(70_000)
    val pulse by loopT(3200, reverse = true)
    val drift by loopT(22_000, reverse = true)
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        val c = Offset(w * 0.20f, h * 0.05f)
        glow(c, w * (0.95f + 0.12f * pulse), 0.50f + 0.14f * pulse)
        rotate(spin * 360f, pivot = c) {
            for (i in 0 until 12) {
                val a = i * 30f * (PI.toFloat() / 180f)
                val len = w * (if (i % 2 == 0) 1.5f else 1.1f)
                val tip = Offset(c.x + cos(a) * len, c.y + sin(a) * len)
                drawLine(
                    Brush.linearGradient(listOf(Color.White.copy(alpha = 0.24f + 0.10f * pulse), Color.Transparent), start = c, end = tip),
                    c, tip, strokeWidth = 24.dp.toPx(),
                )
            }
        }
        glow(c, w * (0.28f + 0.05f * pulse), 0.85f)
        listOf(Triple(0.30f, 0.16f, 0.06f), Triple(0.18f, 0.30f, 0.03f), Triple(0.42f, 0.24f, 0.035f)).forEachIndexed { i, (x, y, r) ->
            val center = Offset(w * x, h * (y + (drift - 0.5f) * 0.02f * (i + 1)))
            drawCircle(Color.White.copy(alpha = 0.10f), radius = w * r, center = center)
            drawCircle(Color.White.copy(alpha = 0.16f), radius = w * r, center = center, style = Stroke(1.5.dp.toPx()))
        }
    }
}

@Composable
private fun NightLayer() {
    val tw by loopT(5000)
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        glow(Offset(w * 0.80f, h * 0.07f), w * 0.55f, 0.28f)
        val rnd = Random(7)
        repeat(48) {
            val base = 0.3f + rnd.nextFloat() * 0.6f
            val r = (0.8f + rnd.nextFloat() * 1.8f).dp.toPx()
            val center = Offset(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.55f)
            val phase = rnd.nextFloat()
            val a = base * (0.55f + 0.45f * sin(2f * PI.toFloat() * (tw + phase)))
            drawCircle(Color.White.copy(alpha = a.coerceIn(0f, 1f)), radius = r, center = center)
        }
    }
}

private class CloudSpec(val base: Float, val y: Float, val scale: Float, val alpha: Float, val speed: Float)

private val cloudSpecs = listOf(
    CloudSpec(0.00f, 0.10f, 0.20f, 0.20f, 1f),
    CloudSpec(0.50f, 0.30f, 0.26f, 0.16f, 1f),
    CloudSpec(0.80f, 0.55f, 0.30f, 0.12f, 1f),
    CloudSpec(0.30f, 0.18f, 0.28f, 0.26f, 2f),
    CloudSpec(0.75f, 0.42f, 0.34f, 0.20f, 2f),
)

private val puffs = listOf(
    Triple(-0.9f, 0.10f, 0.60f), Triple(-0.4f, -0.25f, 0.75f), Triple(0.25f, -0.20f, 0.70f),
    Triple(0.85f, 0.10f, 0.55f), Triple(0.0f, 0.15f, 0.80f),
)

private fun DrawScope.cloud(center: Offset, r: Float, alpha: Float) {
    puffs.forEach { (dx, dy, rr) -> glow(Offset(center.x + dx * r, center.y + dy * r), rr * r, alpha) }
}

/** Cloudy: soft clouds drift across the sky, far ones slowly and near ones faster. */
@Composable
private fun CloudLayer(strength: Float) {
    val t by loopT(80_000)
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        glow(Offset(w * 0.15f, h * 0.10f), w * 0.65f, 0.16f * strength)
        glow(Offset(w * 0.30f, h * 0.52f), w * 0.85f, 0.08f * strength)
        cloudSpecs.forEach { c ->
            val r = c.scale * w
            val x = ((c.base + t * c.speed) % 1f) * (w + 4 * r) - 2 * r
            cloud(Offset(x, h * c.y), r, (c.alpha * strength).coerceAtMost(0.45f))
        }
    }
}

/** Rain: streaks fall continuously; storms also get lightning flashes. */
@Composable
private fun RainLayer(storm: Boolean) {
    val t by loopT(1700)
    val flash by loopT(7000)
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        val rnd = Random(3)
        repeat(if (storm) 130 else 100) {
            val x0 = rnd.nextFloat(); val off = rnd.nextFloat()
            val near = rnd.nextFloat() < 0.4f
            val k = if (near) 2f else 1f
            val len = (if (near) 30f else 18f).dp.toPx()
            val y = ((off + t * k) % 1f) * (h + len) - len
            val x = x0 * (w + 0.3f * h) - y * 0.3f
            drawLine(
                Color.White.copy(alpha = if (near) 0.28f else 0.14f),
                Offset(x, y), Offset(x - len * 0.3f, y + len),
                strokeWidth = (if (near) 2f else 1.2f).dp.toPx(),
            )
        }
        if (storm && ((flash in 0.80f..0.815f) || (flash in 0.84f..0.855f))) {
            drawRect(Color.White.copy(alpha = 0.30f))
        }
    }
}

@Composable
private fun SnowLayer() {
    val t by loopT(11_000)
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        val rnd = Random(5)
        repeat(70) {
            val x0 = rnd.nextFloat(); val off = rnd.nextFloat()
            val r = (1.5f + rnd.nextFloat() * 3f).dp.toPx()
            val a = 0.35f + rnd.nextFloat() * 0.4f
            val phase = rnd.nextFloat()
            val y = ((off + t) % 1f) * (h + 20f) - 10f
            val x = x0 * w + sin(2f * PI.toFloat() * (t * 2f + phase)) * 14.dp.toPx()
            drawCircle(Color.White.copy(alpha = a), radius = r, center = Offset(x, y))
        }
    }
}
