package com.example.weather

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.widget.RemoteViews
import java.text.DateFormat
import java.util.Date

/**
 * Resizable widget: the layout is chosen from the widget's actual size, so it stays readable
 * from a 1x1 corner tile all the way up to a full-screen panel.
 */
class WeatherWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val snap = WeatherStore.load(context)
        ids.forEach { render(context, mgr, it, snap) }
        WeatherUpdateWorker.refreshNow(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, mgr: AppWidgetManager, id: Int, newOptions: android.os.Bundle,
    ) {
        render(context, mgr, id, WeatherStore.load(context))
    }

    override fun onEnabled(context: Context) {
        WeatherUpdateWorker.schedulePeriodic(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) WeatherUpdateWorker.refreshNow(context)
    }

    companion object {
        const val ACTION_REFRESH = "com.example.weather.REFRESH"

        fun updateAll(context: Context, snap: WeatherSnapshot?) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, WeatherWidgetProvider::class.java))
            ids.forEach { render(context, mgr, it, snap) }
        }

        private fun render(context: Context, mgr: AppWidgetManager, id: Int, s: WeatherSnapshot?) {
            val o = mgr.getAppWidgetOptions(id)
            val land = context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            val w = o.getInt(if (land) AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
            val h = o.getInt(if (land) AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)

            val layout = when {
                w == 0 || h == 0 -> R.layout.widget_medium
                w < 110 -> R.layout.widget_xs
                h < 110 -> R.layout.widget_strip
                w >= 220 && h >= 190 -> R.layout.widget_large
                else -> R.layout.widget_medium
            }
            val rv = RemoteViews(context.packageName, layout)

            // Weather-reactive background
            rv.setInt(R.id.w_root, "setBackgroundResource", (s?.sky ?: Sky.CLEAR_DAY).bgRes)

            val temp = s?.let { Units.temp(it.tempC) } ?: "--°"
            val icon = s?.emoji ?: "⛅"
            val stats = s?.let { "💧 ${it.humidity}%   ☔ ${it.rainChance}%" } ?: "Open app to set up"
            val place = s?.place ?: "Weather"
            val cond = s?.let {
                val d = it.days.firstOrNull()
                if (d != null) "${it.label}  H ${Units.temp(d.maxC)}  L ${Units.temp(d.minC)}"
                else "${it.label} · Feels ${Units.temp(it.feelsC)}"
            } ?: "Tap to allow location"

            when (layout) {
                R.layout.widget_xs -> {
                    rv.setTextViewText(R.id.w_icon, icon)
                    rv.setTextViewText(R.id.w_temp, temp)
                }
                R.layout.widget_strip -> {
                    rv.setTextViewText(R.id.w_icon, icon)
                    rv.setTextViewText(R.id.w_temp, temp)
                    rv.setTextViewText(R.id.w_place, place)
                    rv.setTextViewText(R.id.w_stats, stats)
                }
                R.layout.widget_medium -> {
                    rv.setTextViewText(R.id.w_place, place)
                    rv.setTextViewText(R.id.w_icon, icon)
                    rv.setTextViewText(R.id.w_temp, temp)
                    rv.setTextViewText(R.id.w_cond, cond)
                    rv.setTextViewText(R.id.w_stats, stats)
                }
                else -> {
                    rv.setTextViewText(R.id.w_place, place)
                    rv.setTextViewText(R.id.w_icon, icon)
                    rv.setTextViewText(R.id.w_temp, temp)
                    rv.setTextViewText(R.id.w_cond, cond)
                    rv.setTextViewText(R.id.w_humidity, s?.let { "💧 ${it.humidity}%\nHumidity" } ?: "💧 --\nHumidity")
                    rv.setTextViewText(R.id.w_heat, s?.let { "🌡️ ${Units.temp(it.heatIndexC)}\nHeat index" } ?: "🌡️ --\nHeat index")
                    rv.setTextViewText(R.id.w_rain, s?.let { "☔ ${it.rainChance}%\nRain chance" } ?: "☔ --\nRain chance")
                    rv.setTextViewText(R.id.w_wind, s?.let { "💨 ${Units.wind(it.windKmh)}\nWind" } ?: "💨 --\nWind")
                    rv.setTextViewText(
                        R.id.w_updated,
                        s?.let { "Updated " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(it.updatedMs)) } ?: "",
                    )
                    val refresh = Intent(context, WeatherWidgetProvider::class.java).setAction(ACTION_REFRESH)
                    rv.setOnClickPendingIntent(
                        R.id.w_refresh,
                        PendingIntent.getBroadcast(context, id, refresh, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE),
                    )
                }
            }

            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            rv.setOnClickPendingIntent(R.id.w_root, open)
            mgr.updateAppWidget(id, rv)
        }
    }
}
