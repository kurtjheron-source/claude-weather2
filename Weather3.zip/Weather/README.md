# Weather 2.0 (Kotlin, Jetpack Compose, glass UI, native widget)

Live weather for your current location: temperature, humidity, heat index, rain chance, wind.
The app and widget change colour with the real conditions (clear day/night, hot, cloudy, rain, storm, snow, fog).
Data: Open-Meteo (no API key).

## Build the signed APK
Needs JDK 17 and the Android SDK (platform 35). Put `sdk.dir=/path/to/Android/sdk` in `local.properties`, then:

    ./gradlew assembleRelease

Output: `app/build/outputs/apk/release/app-release.apk` (signed with `weather-release.jks`,
credentials in `keystore.properties`). Back both up: you need the same key for every future update.

Or push to GitHub and run the "Build signed APK" workflow. Add secrets KEYSTORE_BASE64
(`base64 -w0 weather-release.jks`) and KEYSTORE_PASSWORD (the value in keystore.properties).

## Widget
Long-press the home screen, Widgets, Weather. It resizes freely and switches layout by size:
icon+temp, strip, medium, and a large panel with all four stats and a refresh button.
